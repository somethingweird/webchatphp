<?php
$db = new mysqli("localhost", "root", "", "private_chat_db");
?>